By installing or using this font, you are agree to the Product Usage Agreement:

1. This font for PERSONAL USE. NO COMMERCIAL USE ALLOWED!
2. You are requires a license for PROMOTIONAL or COMMERCIAL use.
3. LINK TO PURCHASE COMMERSIAL LICENSE:

https://blankidsfonts.com

to DONATE click here:
Paypal.me/blankids

CONTACT ME :
blankids.co@gmail.com

Thanks,
Blankids Studio